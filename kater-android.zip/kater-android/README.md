# Kater

身受許多年輕族群喜愛的匿名社群平台，立志於成為全台灣最多元、開放的社群平台！

![logo](simple-logo.svg)

## Android客戶端

以Apache License 2.0發行程式原始碼

> (c) 2020 [Kater Group](https://kater.me).
